import java.awt.image.BufferedImage;
import java.beans.Statement;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.io.RandomAccessFile;
import java.io.UnsupportedEncodingException; 
import javax.swing.*; 
public class sql {
	  private static final String path = "c:/Path.txt";
	  //�ļ��ŵ�c��
	  public static final String fieldLimitChar = ",";
	  public static final int fieldAllCount = 3;
	  private int count;
	  private String ID;
	  private String Name;
	  private String Path;
	
	//���ݿ����ӣ�����conn
	public static Connection Getconn(){
	 Connection conn = null;
     try{
     conn=DriverManager.getConnection("jdbc:sqlserver://localhost;" + "databaseName=FLLOWER;user=sa;password=123;");
     		
      //System.out.println("�������� ��ɹ�");
     } catch(Exception e)
      {
     e.printStackTrace();
     System.out.print("����ʧ��");
     }
	return conn;  
	}
	//��ѯ����¼����
	public static int seekTable_1count() throws SQLException{
	
		Connection conn = null;
        String sql = "select count(*) from Table_image";
        int i = 0;
        	java.sql.Statement stm = null;
            conn = Getconn();
            stm = conn.createStatement();  
             
            ResultSet rs =  ((java.sql.Statement) stm).executeQuery(sql);
            if(rs.next())
            {
            	i=rs.getInt(1);
            }
            System.out.println("�����ܹ������У�"+i);
            return i;
	}
	//ͼ����������
	public static void dropTable1() throws SQLException{
		Connection conn = null;
        String sql = "truncate table Table_image";
      
        	java.sql.Statement stm = null;
            conn = Getconn();
            stm = conn.createStatement();  
             
            int i =  ((java.sql.Statement) stm).executeUpdate(sql);
           
            if (i == -1) {
             
                System.out.println( "image������գ�");
            }
            conn.close();
	}
	//�������������
	public static void dropTable2() throws SQLException{
		Connection conn = null;
        String sql = "truncate table Table_similar";
      
        	java.sql.Statement stm = null;
            conn = Getconn();
            stm = conn.createStatement();  
             
            int i =  ((java.sql.Statement) stm).executeUpdate(sql);
           
            if (i == -1) {
             
                System.out.println( "similar������գ�");
            }
            conn.close();
	}
	//�Ҷ������������
	public static void dropTable3() throws SQLException{
		Connection conn = null;
        String sql = "truncate table Table_similar_gray";
      
        	java.sql.Statement stm = null;
            conn = Getconn();
            stm = conn.createStatement();  
             
            int i =  ((java.sql.Statement) stm).executeUpdate(sql);
           
            if (i == -1) {
             
                System.out.println( "similar_gray������գ�");
            }
            conn.close();
	}
	
	//���������������
	public static void dropTable4() throws SQLException{
		Connection conn = null;
        String sql = "truncate table Table_Texture";
      
        	java.sql.Statement stm = null;
            conn = Getconn();
            stm = conn.createStatement();  
             
            int i =  ((java.sql.Statement) stm).executeUpdate(sql);
           
            if (i == -1) {
             
                System.out.println( "similar_Texture������գ�");
            }
            conn.close();
	}
	//image����˳�����
	public static boolean insert(String ID,String Name, String Path) throws SQLException {
	        Connection conn = null;
	       
	        boolean flag = false;
	        String sql = "insert into Table_image values('" + ID + "','"
	                + Name + "','" + Path + "')";
	        try {
	        	java.sql.Statement stm = null;
	            conn = Getconn();
	            stm = conn.createStatement();  
	             
	            int i =  ((java.sql.Statement) stm).executeUpdate(sql);
	            if (i > 0) {
	             
	                System.out.println( "���ݵ��� �ɹ���");
	            }
	        } catch (Exception e) {
	            flag = false;
	            e.printStackTrace();
	       }
	        conn.close();
	        return flag;
	    }

    //�ر��������
	public static void close(ResultSet rs, Statement stm, Connection conn) {
	        if (rs != null)
	            try {
	                rs.close();
	            } catch (Exception e) {
	                e.printStackTrace();
	            }
	        if (stm != null)
	            try {
	                ((Connection) stm).close();
	            } catch (Exception e) {
	                e.printStackTrace();
	            }
	        if (conn != null)
	            try {
	                conn.close();
	            } catch (Exception e) {
	                e.printStackTrace();
	            }
	    }
	 
	//����Path.txt
	public void loadFile() {
	        try {
	            RandomAccessFile raf = new RandomAccessFile(path, "r");
	            String line_record = raf.readLine();//ÿһ�����ݸ�����
	            while (line_record != null) {
	                // ����ÿһ����¼
	                parseRecord(line_record);
	                line_record = raf.readLine();//IO��read���ƶ���ת����һ��
	            }
	            //System.out.println("���кϷ��ļ�¼" + count + "��");
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	    //���е���
	private void parseRecord(String line_record) throws Exception {
	    
	           String[] fields = line_record.split(fieldLimitChar);//ȥ�ָ���","
	           if (fields.length == fieldAllCount) {
	               ID =  tranStr(fields[0]);
	               Name = tranStr(fields[1]);
	               Path = tranStr(fields[2]);
	              
	               System.out.println(ID + " " + Name + " " + Path);
	               
	               insert(ID,Name,Path);
	               count++;
	           }
	       }
	//ת��׼�ַ�����	
	private String tranStr(String oldstr) {
	        String newstr = "";
	        try {
	            newstr = new String(oldstr.getBytes("ISO-8859-1"), "GBK");
	        } catch (UnsupportedEncodingException e) {
	            e.printStackTrace();
	        }
	        return newstr;
	    }
    //��ѯ��ͼƬ·��
	public static String seekpath(String i) throws SQLException {
			// TODO Auto-generated method stub
			  Connection conn = null;
		       
		        String datapath = null ;
		        String sql = "select Path from Table_image where ID='"+i+"' ";
		        try {
		        	java.sql.Statement stm = null;
		            conn = Getconn();
		            stm = conn.createStatement();  
		             
		            ResultSet rs = ((java.sql.Statement) stm).executeQuery(sql);
		            if(rs.next())
		            { 
		            	datapath=rs.getString("Path");
		            }
		            //System.out.println("����·��"+datapath);
		        } catch (Exception e) {
		            e.printStackTrace();
		       }
		       
		        conn.close();
		        
		        return datapath;
		}
	
}


