import java.awt.image.BufferedImage;
import java.beans.Statement;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.io.RandomAccessFile;
import java.io.UnsupportedEncodingException; 
import java.io.IOException;
public class sql_s {

	public static String[] sort_rpg = new String[48];
	public static String[] sort_gray = new String[48];
	public static String[] rgbx = new String[48];
	public static String[] grayx = new String[48];
	 //һ���򵥵������ַ����������ĳ���
	 public static String getpath()
		{
			String seekpath=null;
			System.out.println("����Ŀ��ͼƬ·��");
	        Scanner spath = new Scanner(System.in);
	        seekpath=spath.next();
	        //System.out.println("Ŀ��·��Ϊ"+seekpath);
	       
			return seekpath;
		    
		}
	
    //similar�����Ƚ� 
   public static float seek_similar(String datapath,String seekpath){
    	 
     double similar=(double)0.0;//���ƶ�		 
     int[][] result1,result2;//���ÿ�����ص�rgbֵ��δ������
     double [][] h1=new double [3][256];//���rgb�Ҷ�ֱ��ͼ����������ֵ
     double [][] h2=new double [3][256];
     
     rgb rgb1=new rgb();
     rgb rgb2=new rgb();	 
//     System.out.println("����Ŀ��ͼƬ·��(c:/springflowers/Image06.jpg)");
//     Scanner in =new Scanner(System.in);
//     String seekpath=in.next();
     
     result1=rgb1.getImageRGB(seekpath);//��ȡa_rgb������ֱ��ͼ
     result2=rgb2.getImageRGB(datapath);

     //int i=result1.length,j=result1[0].length;
     
     h1=rgb1.GetHistogram(result1);//����rgb�����ֱ��ͼ
     h2=rgb1.GetHistogram(result2);
     
     //System.out.println(" "+h1[0][46]+" "+"i:"+i+"  "+"j:"+j);//7.3.8.42  i��jû�д�����
	    
     similar=rgb.GetSimilar(h1,h2);
     
     return (float) similar;
     }
   
   //similar_gray�����Ƚ�
   public static float seek_similar_gray(String datapath,String seekpath){
  	 
	     double similar=(double)0.0;//���ƶ�		 
	     int[][] result1,result2;//���ÿ�����ص�rgbֵ��δ������
	     double [] h1=new double [256];//���rgb�Ҷ�ֱ��ͼ����������ֵ
	     double [] h2=new double [256];
	     
	     rgb rgb1=new rgb();
	     rgb rgb2=new rgb();	 
//	     System.out.println("����Ŀ��ͼƬ·��(c:/springflowers/Image06.jpg)");
//	     Scanner in =new Scanner(System.in);
//	     String seekpath=in.next();
	     
	     result1=rgb1.getImageRGB(seekpath);//��ȡa_rgb������ֱ��ͼ
	     result2=rgb2.getImageRGB(datapath);

	     //int i=result1.length,j=result1[0].length;
	     
	     h1=rgb1.GetHistogram_gray(result1);//����rgb�����ֱ��ͼ
	     h2=rgb2.GetHistogram_gray(result2);
	     
	     //System.out.println(" "+h1[0][46]+" "+"i:"+i+"  "+"j:"+j);//7.3.8.42  i��jû�д�����
		    
	     similar=rgb.GetSimilar_gray(h1,h2);
	     
	     return (float) similar;
	     }
   
   //Table_similar������������
   public static boolean insert_similar(String ID,float similar,String datapath) throws SQLException {
       Connection conn = null;
      
       boolean flag = false;
       String sql = "insert into Table_similar values('" + ID + "','"
               + similar + "','"+datapath+"')";
       try {
       	java.sql.Statement stm = null;
       	   sql Sql=new sql();
           conn = Sql.Getconn();
           stm = conn.createStatement();  
            
           int i =  ((java.sql.Statement) stm).executeUpdate(sql);
           if (i > 0) {
            
               System.out.println( "ͼ�� "+ID+" �Ƚ� �ɹ���");
           }
       } catch (Exception e) {
           flag = false;
           e.printStackTrace();
      }
       conn.close();
       return flag;
   }

   //Table_similar_gray����
   public static boolean insert_similar_gray(String ID,float similar,String datapath) throws SQLException {
       Connection conn = null;
      
       boolean flag = false;
       String sql = "insert into Table_similar_gray values('" + ID + "','"
               + similar + "','"+datapath+"')";
       try {
       	java.sql.Statement stm = null;
       	   sql Sql=new sql();
           conn = Sql.Getconn();
           stm = conn.createStatement();  
            
           int i =  ((java.sql.Statement) stm).executeUpdate(sql);
           if (i > 0) {
            
               System.out.println( "ͼ�� "+ID+" �Ƚ� �ɹ���");
           }
       } catch (Exception e) {
           flag = false;
           e.printStackTrace();
      }
       conn.close();
       return flag;
   }
//�ر��������
   public static void close(ResultSet rs, Statement stm, Connection conn) {
       if (rs != null)
           try {
               rs.close();
           } catch (Exception e) {
               e.printStackTrace();
           }
       if (stm != null)
           try {
               ((Connection) stm).close();
           } catch (Exception e) {
               e.printStackTrace();
           }
       if (conn != null)
           try {
               conn.close();
           } catch (Exception e) {
               e.printStackTrace();
           }
   }
   
   //similar�Ӹߵ�������
   public static void seek_sort()throws SQLException{
	   Connection conn = null;
	      
       boolean flag = false;
       String sql = "select  ID,similar,datapath from Table_similar order by similar DESC";
       try {
       	java.sql.Statement stm = null;
       	   sql Sql=new sql();
           conn = Sql.Getconn();
           stm = conn.createStatement();  
            
           ResultSet rs =  ((java.sql.Statement) stm).executeQuery(sql);
           int count=0;
           while(rs.next()){
        	   sort_rpg[count]=rs.getString("datapath");
        	   rgbx[count]=rs.getString("similar");
        	   count++;
        	   System.out.println(count+":  ͼ��"+rs.getString("ID")+"  "+rs.getString("similar"));
        	   }
       } catch (Exception e) {
           flag = false;
           e.printStackTrace();
      }
       conn.close();
   }


  //similar_gray�Ӹߵ���
  public static void seek_sort_gray()throws SQLException{
	   Connection conn = null;
	      
    boolean flag = false;
    String sql = "select  ID,similar,datapath from Table_similar_gray order by similar DESC";
    try {
    	java.sql.Statement stm = null;
    	   sql Sql=new sql();
        conn = Sql.Getconn();
        stm = conn.createStatement();  
         
        ResultSet rs =  ((java.sql.Statement) stm).executeQuery(sql);
        int count=0;
        while(rs.next()){
     	   
     	  sort_gray[count]=rs.getString("datapath");
     	  grayx[count]=rs.getString("similar");;
     	  count++;
     	   System.out.println(count+":  ͼ��"+rs.getString("ID")+"  "+rs.getString("similar"));
     	   }
    } catch (Exception e) {
        flag = false;
        e.printStackTrace();
   }
    conn.close();
  }
  
  
}
