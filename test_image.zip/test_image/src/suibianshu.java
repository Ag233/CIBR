


import java.awt.EventQueue;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

import javax.imageio.ImageIO;
import javax.swing.AbstractButton;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import java.awt.Button;
import java.awt.BorderLayout;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JTree;
import javax.swing.SwingConstants;
import javax.swing.JComponent;
import javax.swing.JFileChooser;

import java.awt.Font;
import java.awt.TextField;
import java.awt.Color;

public class suibianshu implements ActionListener{

	String[] sort_rpg = new String[48];
	String[] sort_gray = new String[48];
	String[] sort_Texture = new String[48];
	int width=126;
	int height=84;
	JFrame frame;
	JFrame frame1;
	JFrame frame2;
	JFrame frame3;
	JButton B1;
	JButton B2;
	JButton B3;
	public JFileChooser jfc=new JFileChooser();
	
	private JButton B5;
	private JButton B4;
	TextField text1 = new TextField();
	private JButton B6;
	

	
    private String s1;
    private JLabel lblNewLabel;
    private JLabel label_1;
    private JLabel label_2;
   
	public static void main(String[] args) {
		
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					suibianshu window = new suibianshu();
					
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public suibianshu() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	public void initialize() {
		frame = new JFrame("�������ݵ�ͼ�������");
		frame1 =new JFrame("R,G,Bֱ���ཻ");
		frame1.getContentPane().setLayout(null);
		
		frame2 =new JFrame("Grayֱ���ཻ");
		frame2.getContentPane().setLayout(null);
		
		frame3 =new JFrame("�����ҶȲ��");
		frame3.getContentPane().setLayout(null);
		B1 = new JButton("\u989C\u8272-RGB\u76F4\u65B9\u76F8\u4EA4");
		B1.setBackground(Color.PINK);
		B1.setFont(new Font("����", Font.PLAIN, 11));
		B1.setHorizontalAlignment(SwingConstants.LEFT);
		B1.setBounds(10, 95, 133, 59);
		
		frame.getContentPane().setLayout(null);
		
        frame.getContentPane().add(B1);
		
		B2 = new JButton("\u989C\u8272-Gray\u76F4\u65B9\u76F8\u4EA4");
		B2.setBackground(Color.PINK);
		B2 .setFont(new Font("����", Font.PLAIN, 11));
		B2 .setBounds(196, 95, 133, 59);
		
		frame.getContentPane().add(B2 );
		
		B3 = new JButton("\u7EB9\u7406-\u7070\u5EA6\u5DEE\u5206\u8DDD\u79BB");
		B3.setBackground(Color.PINK);
		B3.setFont(new Font("����", Font.PLAIN, 11));
		B3.setBounds(423, 95, 133, 59);
		
		frame.getContentPane().add(B3);
		
		jfc.setCurrentDirectory(new File("c:\\"));//��c�̿�ʼ
		
		B4 = new JButton("\u67E5\u8BE2\u76EE\u6807\u8DEF\u5F84");
		B4.setBackground(Color.ORANGE);
		B4.setForeground(Color.BLACK);
		B4.setBounds(10, 9, 148, 59);
		frame.getContentPane().add(B4);
		
		B5 = new JButton("\u6E05\u7406\u6570\u636E\u5E93");
		B5.setBackground(Color.RED);
		B5.setFont(new Font("����", Font.PLAIN, 13));
		B5.setBounds(612, 95, 133, 59);
		frame.getContentPane().add(B5);
		text1.setText("\u5148\u9009\u76EE\u6807\u8DEF\u5F84,\u5355\u6B21\u4F7F\u7528\uFF0C\u7528\u5B8C\u6E05\u7406\u6570\u636E\u5E93");
		
		
		text1.setBounds(196, 27, 360, 23);
		frame.getContentPane().add(text1);
		
		B6 = new JButton("\u5BFC\u5165\u56FE\u5E93");
		B6.setBackground(Color.CYAN);
		B6.setBounds(612, 9, 147, 59);
		frame.getContentPane().add(B6);
		
		
		
		label_1 = new JLabel();
		label_2 = new JLabel();
		
		
		
		
		
		
		B1.addActionListener(new B1());
		B2.addActionListener(new B2());
		B3.addActionListener(new B3());
		B4.addActionListener(new B4());
		B5.addActionListener(new B5());
		B6.addActionListener(new B6());
	
		frame.setBounds(100, 100, 800, 1200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

    //��ɫrpgֱ���ཻƥ���ڲ���
	class B1 implements ActionListener{
	public void actionPerformed(ActionEvent event) {
		
		
		// TODO Auto-generated method stub
		
		try {
			sort_rpg=test.show_rpg();
//			B1.setText("231");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			int j=136;
			for(int i=0;i<6;i++){
				//label_2����ͼƬ
			label_2=new JLabel(sql_s.rgbx[i]);
			label_2.setBounds(10+i*j, 100, 126, 50);
			File sourceimage = new File(sort_rpg[i]);
			System.out.printf("��һ��Ϊ"+sort_rpg[i]);
			BufferedImage image;
			image = ImageIO.read(sourceimage);
			ImageIcon im = new ImageIcon(image);
			label_1 = new JLabel(im);
			label_1.setBounds(10+i*j, 10, 126, 84);
			Image img = im.getImage();  
			img = img.getScaledInstance(width, height, Image.SCALE_DEFAULT);  
			im.setImage(img);  
			label_1.setIcon(im);
			frame1.getContentPane().add(label_1);
			frame1.getContentPane().add(label_2);
			}
			for(int i=6;i<12;i++){
				//label_2����ͼƬ
				label_2=new JLabel(sql_s.rgbx[i]);
				label_2.setBounds(10+(i-6)*j, 300, 126, 50);
				File sourceimage = new File(sort_rpg[i]);
				System.out.printf("��һ��Ϊ"+sort_rpg[i]);
				//��ͼƬ�����Ӧlabel_1
				BufferedImage image;
				image = ImageIO.read(sourceimage);
				ImageIcon im = new ImageIcon(image);
				label_1 = new JLabel(im);
				label_1.setBounds(10+(i-6)*j, 194, 126, 84);
				Image img = im.getImage();  
				img = img.getScaledInstance(width, height, Image.SCALE_DEFAULT);  
				im.setImage(img);  
				label_1.setIcon(im);
				frame1.getContentPane().add(label_1);
				frame1.getContentPane().add(label_2);
				}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		frame1.setVisible(true);
		frame1.setBounds(100, 100, 1000,500);
	
		///ʹͼƬ��Ӧ��ǩ�Ĵ�С
		
	}
	}
	//��ɫgrayֱ���ཻƥ���ڲ���
	class B2 implements ActionListener{
		public void actionPerformed(ActionEvent event) {
			
			try {
				sort_gray=test.show_gray();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try {
				int j=136;
				for(int i=0;i<6;i++){
					//ƥ���
					label_2=new JLabel(sql_s.grayx[i]);
					label_2.setBounds(10+i*j, 100, 126, 50);
				File sourceimage = new File(sort_gray[i]);
				System.out.printf("��һ��Ϊ"+sort_gray[i]);
				BufferedImage image;
				//��ͼƬ�����Ӧlabel_1
				image = ImageIO.read(sourceimage);
				ImageIcon im = new ImageIcon(image);
				label_1 = new JLabel(im);
				label_1.setBounds(10+i*j, 10, 126, 84);
				Image img = im.getImage();  
				img = img.getScaledInstance(width, height, Image.SCALE_DEFAULT);  
				im.setImage(img);  
				label_1.setIcon(im);
				frame2.getContentPane().add(label_1);
				frame2.getContentPane().add(label_2);
				}
				for(int i=6;i<12;i++){
					label_2=new JLabel(sql_s.grayx[i]);
					label_2.setBounds(10+(i-6)*j, 300, 126, 50);
					File sourceimage = new File(sort_gray[i]);
					System.out.printf("��һ��Ϊ"+sort_gray[i]);
					BufferedImage image;
					image = ImageIO.read(sourceimage);
					ImageIcon im = new ImageIcon(image);
					label_1 = new JLabel(im);
					label_1.setBounds(10+(i-6)*j, 194, 126, 84);
					Image img = im.getImage();  
					img = img.getScaledInstance(width, height, Image.SCALE_DEFAULT);  
					im.setImage(img);  
					label_1.setIcon(im);
					frame2.getContentPane().add(label_1);
					frame2.getContentPane().add(label_2);	
				}
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			frame2.setVisible(true);
			frame2.setBounds(100, 100, 1000,500);
		}
		}

	//�����ҶȲ�
	class B3 implements ActionListener{
		public void actionPerformed(ActionEvent event) {
			
			
			// TODO Auto-generated method stub
			
			try {
				sort_Texture=test.show_Texture();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try {
				int j=136;
				for(int i=0;i<6;i++){
					label_2=new JLabel(Texture.Texturex[i]);
					label_2.setBounds(10+i*j, 100, 126, 50);
				File sourceimage = new File(sort_Texture[i]);
				System.out.printf("��һ��Ϊ"+sort_Texture[i]);
				BufferedImage image;
				image = ImageIO.read(sourceimage);
				ImageIcon im = new ImageIcon(image);
				label_1 = new JLabel(im);
				label_1.setBounds(10+i*j, 10, 126, 84);
				Image img = im.getImage();  
				img = img.getScaledInstance(width, height, Image.SCALE_DEFAULT);  
				im.setImage(img);  
				label_1.setIcon(im);
				frame3.getContentPane().add(label_1);
				frame3.getContentPane().add(label_2);
				}
				for(int i=6;i<12;i++){
					label_2=new JLabel(Texture.Texturex[i]);
					label_2.setBounds(10+(i-6)*j, 300, 126, 50);
					File sourceimage = new File(sort_Texture[i]);
					System.out.printf("��һ��Ϊ"+sort_Texture[i]);
					BufferedImage image;
					image = ImageIO.read(sourceimage);
					ImageIcon im = new ImageIcon(image);
					label_1 = new JLabel(im);
					label_1.setBounds(10+(i-6)*j, 194, 126, 84);
					Image img = im.getImage();  
					img = img.getScaledInstance(width, height, Image.SCALE_DEFAULT);  
					im.setImage(img);  
					label_1.setIcon(im);
					frame3.getContentPane().add(label_1);
					frame3.getContentPane().add(label_2);
					}
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			frame3.setVisible(true);
			frame3.setBounds(100, 100, 1000,500);
		}
		}
	
	//��ȡĿ��ͼƬ·��
	class B4 implements ActionListener{
		public void actionPerformed(ActionEvent event) {
			
			
			jfc.setFileSelectionMode(0);//�趨ֻ��ѡ���ļ�
            int state=jfc.showOpenDialog(null);//�˾��Ǵ��ļ�ѡ��������Ĵ������
            if(state==1){
                return;//�����򷵻�
            }
            else{
                File f=jfc.getSelectedFile();//fΪѡ�񵽵��ļ�
                text1.setText(f.getAbsolutePath());
                s1=f.getAbsolutePath();
               //System.out.println(s1);
                test.get_seek_path(s1);
            }
		}
		}
	//������ݿ�
	class B5 implements ActionListener{
		public void actionPerformed(ActionEvent event) {
			
			
			// TODO Auto-generated method stub
			B5.setText("�ٴ�����");
			try {
				test.drop();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		}
	//�������ݿ⣬����ƥ��ȼ���
	class B6 implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			
			
			// TODO Auto-generated method stub
			B6.setText("������ɣ�");
			try {
				test.loadfile();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
}
/*
File sourceimage = new File(rs.getString("Path")); 
image = ImageIO.read(sourceimage);

///ʹͼƬ��Ӧ��ǩ�Ĵ�С
ImageIcon im = new ImageIcon(image);
JLabel label = new JLabel(im);
Image img = im.getImage();  
img = img.getScaledInstance(width, height, Image.SCALE_DEFAULT);  
im.setImage(img);  
label.setIcon(im);
*/